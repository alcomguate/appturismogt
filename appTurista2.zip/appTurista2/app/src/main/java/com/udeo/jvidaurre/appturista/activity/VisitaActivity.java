package com.udeo.jvidaurre.appturista.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.udeo.jvidaurre.appturista.R;

public class VisitaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visita);
    }
}
